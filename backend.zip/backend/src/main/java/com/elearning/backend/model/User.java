package com.elearning.backend.model;

public class User {

}
